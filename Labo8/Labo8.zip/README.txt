1- Run npm install
2- Démarrer le serveur avec node index.js
3- Allez à localhost:8080/login
4- Créer un compte avec register
5- Connectez vous!